var class_base_part_handler =
[
    [ "BasePartHandler", "class_base_part_handler.html#a1be867fe3157843e434696c105c0bb59", null ],
    [ "handlePart", "class_base_part_handler.html#ac2764e4ffe491b5bbeb5cfcbfacca136", null ],
    [ "‾BasePartHandler", "class_base_part_handler.html#a5bd02d5b487b239656c5c7ba0ca7c37b", null ],
    [ "_log", "class_base_part_handler.html#a33a07b67ec61e0a05379ba45e8f25815", null ]
];