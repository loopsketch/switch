var class_performance_timer =
[
    [ "PerformanceTimer", "class_performance_timer.html#a019954368c10608bc81c392ee3691797", null ],
    [ "getTime", "class_performance_timer.html#a1bc6afebae04a5f0f661aeeda218110b", null ],
    [ "start", "class_performance_timer.html#a765aaf76a56dfc0ec58066ab4558051f", null ],
    [ "update", "class_performance_timer.html#af94bbc72e66be8e6a853988a2935ee00", null ],
    [ "‾PerformanceTimer", "class_performance_timer.html#a7e43787338d24c3c05202a0808574e08", null ],
    [ "_current", "class_performance_timer.html#aa4b980ca05b3391a81094157d89957ac", null ],
    [ "_enabled", "class_performance_timer.html#a2da5c5688f73cbb50e58f4448b168d5d", null ],
    [ "_freq", "class_performance_timer.html#ac77e06f54026d9300b8325220da2802b", null ],
    [ "_start", "class_performance_timer.html#ac98c30574630defe1db1c04ba36b680b", null ]
];