var _utils_8cpp =
[
    [ "BUFFER_SIZE", "_utils_8cpp.html#a6b20d41d6252e9871430c242cb1a56e7", null ]
];