var class_play_list =
[
    [ "PlayList", "class_play_list.html#ae9067d7d85852298d77fe6ff96f3ffff", null ],
    [ "add", "class_play_list.html#a90d869445f16cf9b431cefa2dada9c70", null ],
    [ "id", "class_play_list.html#a63d9c8db4c8c87b490987530cf0f85ff", null ],
    [ "itemCount", "class_play_list.html#a54d0bb384e05db0d4a2b3a6084f954a0", null ],
    [ "items", "class_play_list.html#adf3736f925adc0756564f1fc9249d40c", null ],
    [ "name", "class_play_list.html#acfd78dd994827cca98713d5ff8669e07", null ],
    [ "text", "class_play_list.html#a0ab61ce35e3f79b0112b9830c1c90331", null ],
    [ "text", "class_play_list.html#a1dce922b5677f507ff1c4403638b78ba", null ],
    [ "‾PlayList", "class_play_list.html#a714660fe1a0ff21d5602d9e22d64f4b4", null ],
    [ "Workspace", "class_play_list.html#a97bcc5da9b5e308637f70865925452ec", null ],
    [ "_id", "class_play_list.html#a4e4883f2095d1f29bd63454c4c5f6342", null ],
    [ "_items", "class_play_list.html#a5f7d810e600a4c15d779968b42d3bd5a", null ],
    [ "_log", "class_play_list.html#afc3f7bc01f8d8c013cfb971e90b4a75b", null ],
    [ "_name", "class_play_list.html#a4623e6b421a9431f1bee310140381ac5", null ],
    [ "_text", "class_play_list.html#aafca1a1f8ade2626802253087d9878e2", null ]
];