var class_f_p_s_counter =
[
    [ "FPSCounter", "class_f_p_s_counter.html#a4dff969224168c259394cc369ff13cf4", null ],
    [ "calculation", "class_f_p_s_counter.html#a5a528fc2f2223073c23f8a40e47c8590", null ],
    [ "count", "class_f_p_s_counter.html#a5ff4b09c27726e07474844005b94265c", null ],
    [ "getFPS", "class_f_p_s_counter.html#a3e8a29191ca23e1353724c471d888f75", null ],
    [ "start", "class_f_p_s_counter.html#a764388e732070bea6b7a83c24ad4b574", null ],
    [ "‾FPSCounter", "class_f_p_s_counter.html#af47db571374f89ca29ee9e2843e7d3d2", null ],
    [ "_count", "class_f_p_s_counter.html#a487ea25427d9ed6c1497e25d6e56f384", null ],
    [ "_fps", "class_f_p_s_counter.html#a995acda9ffd3d7a6ebee49cacd8cbc41", null ]
];