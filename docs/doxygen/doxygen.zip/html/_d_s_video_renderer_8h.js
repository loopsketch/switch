var _d_s_video_renderer_8h =
[
    [ "DSVideoRendererPtr", "_d_s_video_renderer_8h.html#ad728ea8206a1073fcaab76317418af59", null ],
    [ "__declspec", "_d_s_video_renderer_8h.html#a38dc5310cc89d2b6043e9120b1cf9b08", null ]
];