var class_switch_request_handler =
[
    [ "SwitchRequestHandler", "class_switch_request_handler.html#a9355f82a95a87f24ffd0361822db5276", null ],
    [ "clearStock", "class_switch_request_handler.html#adb10a816dcbff962ba8adb3d8adbbae0", null ],
    [ "copy", "class_switch_request_handler.html#a2162e9b315ba7ba732ac04e43ada6cb3", null ],
    [ "doRequest", "class_switch_request_handler.html#ae5a91f90036f8ff5f1c95850fcc57ddf", null ],
    [ "download", "class_switch_request_handler.html#aabc3001a4368756689ad2d81e265d2be", null ],
    [ "files", "class_switch_request_handler.html#ad11cf606f15ba11b16d32d6f66181848", null ],
    [ "fileToJSON", "class_switch_request_handler.html#ad245f2e0f3a5da74011abf531587272f", null ],
    [ "get", "class_switch_request_handler.html#a3232ed0a468e78d7f60bfb0f6e17caaf", null ],
    [ "set", "class_switch_request_handler.html#a4109df746684ce6c254ff80abd187692", null ],
    [ "switchContent", "class_switch_request_handler.html#a35194c8cf5215afd3819e7990f3c3d01", null ],
    [ "updateWorkspace", "class_switch_request_handler.html#abae191ed0ec62c6a82277f5f1914b67c", null ],
    [ "upload", "class_switch_request_handler.html#a32926e4d6f540282c7229543b70a0baf", null ],
    [ "version", "class_switch_request_handler.html#a440d7438c880327f0b037df5bf97c8d3", null ],
    [ "‾SwitchRequestHandler", "class_switch_request_handler.html#acaeefb05489c82a9276d5ef4178d8f3f", null ],
    [ "_renderer", "class_switch_request_handler.html#aad78fbc219290b7eaceb6659faf708b3", null ]
];