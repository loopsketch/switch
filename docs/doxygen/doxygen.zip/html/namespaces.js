var namespaces =
[
    [ "svvitch", "namespacesvvitch.html", "namespacesvvitch" ]
];