var _configuration_8h =
[
    [ "ConfigurationPtr", "_configuration_8h.html#a756753fd1e9065d6dc98be7e623cbb04", null ]
];