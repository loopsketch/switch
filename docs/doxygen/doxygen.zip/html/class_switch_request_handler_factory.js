var class_switch_request_handler_factory =
[
    [ "SwitchRequestHandlerFactory", "class_switch_request_handler_factory.html#a7caad510a266a9a7d77b620c84d48379", null ],
    [ "createRequestHandler", "class_switch_request_handler_factory.html#a23a883a50b9e4661aaa9a0ccb7bfdf24", null ],
    [ "‾SwitchRequestHandlerFactory", "class_switch_request_handler_factory.html#a61d8da2a0ea605e885789336efd093fa", null ],
    [ "_log", "class_switch_request_handler_factory.html#ac00d6286f3b034a14e05dae28f09dfc2", null ],
    [ "_renderer", "class_switch_request_handler_factory.html#a6e5fb432af1cbac554157050e0d090a3", null ]
];