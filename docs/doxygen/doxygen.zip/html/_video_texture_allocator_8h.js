var _video_texture_allocator_8h =
[
    [ "VideoTextureAllocatorPtr", "_video_texture_allocator_8h.html#a13638ec9a11d3d97eb9ae36dac0f8d3d", null ]
];