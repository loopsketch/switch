var class_dissolve_transition =
[
    [ "DissolveTransition", "class_dissolve_transition.html#aa920405ce15a16f2abb01a0897e678be", null ],
    [ "initialize", "class_dissolve_transition.html#af46dd0dd1781d92b790ced31f30d9c10", null ],
    [ "process", "class_dissolve_transition.html#ab955e88b8aed5d232663bd7f3b82fed9", null ],
    [ "‾DissolveTransition", "class_dissolve_transition.html#a58f1f1b68081f1748c095d9d15b81f4e", null ],
    [ "_speed", "class_dissolve_transition.html#a99ddc4ecb3acd349f564e073d77d175b", null ]
];