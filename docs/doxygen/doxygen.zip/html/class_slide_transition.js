var class_slide_transition =
[
    [ "SlideTransition", "class_slide_transition.html#a4c2f4546b69212e52aec32038771062f", null ],
    [ "initialize", "class_slide_transition.html#a0df0f3281b7f962addbf352ec06d3b58", null ],
    [ "process", "class_slide_transition.html#a70ef4dadb32da2b377b664000445ee1b", null ],
    [ "‾SlideTransition", "class_slide_transition.html#ab430cf1c6fad3f67f800032d658bfb74", null ],
    [ "_offsetX", "class_slide_transition.html#ad31a40ea2854df756b97a5d501472a38", null ],
    [ "_offsetY", "class_slide_transition.html#a640c4aea949e9e8ea2d9dff6e3c15842", null ],
    [ "_speed", "class_slide_transition.html#a055a71b41e25e0a6f0715c0acc5c992b", null ]
];