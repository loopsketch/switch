var searchData=
[
  ['queryinterface',['QueryInterface',['../class_control_site.html#a41b23ea814e38fd94bd86dd2340b10a0',1,'ControlSite::QueryInterface()'],['../class_flash_sink.html#a8bac211baa51421e365dabf2ad3bd4cf',1,'FlashSink::QueryInterface()'],['../class_video_texture_allocator.html#a75862b83f91e894eb663b54ddaebccb8',1,'VideoTextureAllocator::QueryInterface()']]]
];
